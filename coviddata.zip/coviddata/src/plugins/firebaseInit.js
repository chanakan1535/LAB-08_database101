// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyDUf7EVesYWd8_uk2ydRTNAVjtGFJC0-3o",
  authDomain: "fir-10100.firebaseapp.com",
  projectId: "fir-10100",
  storageBucket: "fir-10100.appspot.com",
  messagingSenderId: "657538452370",
  appId: "1:657538452370:web:86677b04fda6f8547e4f4b",
  measurementId: "G-WM4EHYR71M",
});

const db = getFirestore(firebaseApp);
export default db;
