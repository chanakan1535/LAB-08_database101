<template>
  <v-form v-model="valid">
    <v-container>
      <h1>กรอกข้อมูล</h1>
      <v-row>
        <v-col cols="12" md="4">
          <v-text-field
            v-model="nameC"
            :rules="nameRules"
            :counter="25"
            label="First name"
            required
          ></v-text-field>
        </v-col>

        <v-col cols="12" md="4">
          <v-text-field
            v-model="lastnameC"
            :rules="nameRules"
            :counter="25"
            label="Last name"
            required
          ></v-text-field>
        </v-col>

        <v-col cols="12" md="4">
          <v-text-field
            v-model="mails"
            :rules="emailRules"
            label="E-mail"
            required
          ></v-text-field>
        </v-col>
      </v-row>

      <span>ผลตรวจATK</span>
      <v-col cols="12" sm="4" md="4">
        <v-checkbox
          v-model="checkedNames"
          label="+"
          color="red"
          value="+"
          hide-details
        ></v-checkbox>
        <v-checkbox
          v-model="checkedNames"
          label="-"
          color="success"
          value="-"
          hide-details
        ></v-checkbox>
      </v-col>
      <v-col cols="12" md="4">
        <v-text-field
          v-model="numberphone"
          :rules="nameRules"
          :counter="10"
          label="numberphone"
          required
        ></v-text-field>
      </v-col>
      <v-row align="center" justify="space-around">
        <div class="text-center">
          <v-btn @click="addData()"> summit </v-btn>
        </div>
        <div class="text-center">
          <v-btn @click="readData()" color="error"> show </v-btn>
        </div>
      </v-row>
      <h4>{{ dbData }}</h4>
      <v-container>
        <v-simple-table dense>
          <template v-slot:default>
            <thead>
              <tr>
                <th scope="col">ลำดับ</th>
                <th scope="col">ชื่อ</th>
                <th scope="col">นามสกุล</th>
                <th scope="col">ATK</th>
                <th scope="col">E-mail</th>
                <th scope="col">เบอร์โทรศัพท์</th>
              </tr>
            </thead>
            <tbody v-for="(item, index) in table" :key="index">
              <tr>
                <th scope="row">{{ index }}</th>
                <td>{{ item.data.name }}</td>
                <td>{{ item.data.lastname }}</td>
                <td>{{ item.data.atk }}</td>
                <td>{{ item.data.mail }}</td>
                <td>{{ item.data.number }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-container>
    </v-container>
  </v-form>
</template>
<script>
import db from "../plugins/firebaseInit";
import { collection, addDoc, getDocs } from "firebase/firestore";

export default {
  data() {
    return {
      dbData: "",
      nameC: " ",
      lastnameC: "",
      checkedNames: "",
      mails: "",
      numberphone: "",
      table: [],
    };
  },
  methods: {
    async addData() {
      try {
        const docRef = await addDoc(collection(db, "book2"), {
          name: this.nameC,
          lastname: this.lastnameC,
          atk: this.checkedNames,
          mail: this.mails,
          number: this.numberphone,
        });
        console.log("Document written with ID: ", docRef.id);
      } catch (e) {
        console.error("Error adding document: ", e);
      }
    },
    async readData() {
      const querySnapshot = await getDocs(collection(db, "book2"));
      querySnapshot.forEach((doc) => {
        console.log(`${doc.id} => ${doc.data()}`);
        this.table.push({ id: doc.id, data: doc.data() });
      });
    },
    /* addit() {
      this.additems.push({
        text: this.nameC,
      });
    },*/
  },
};
</script>
<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
