<template>
  <v-app>
    <v-app-bar app color="error" dark>
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://datagov.mot.go.th/uploads/group/2021-05-03-043645.891115face-mask.png"
          transition="scale-transition"
          width="55"
        />
      </div>

      <v-spacer></v-spacer>
      <v-btn to="/" text>
        <span class="mr-2">Home</span>
      </v-btn>
      <v-btn to="/About" text>
        <span class="mr-2">ลงข้อมูล</span>
        <v-icon dark> mdi-plus </v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "App",

  data: () => ({
    //
  }),
};
</script>
